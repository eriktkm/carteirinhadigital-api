package br.senai.carteirinha.modules.usuario.application;

import br.senai.carteirinha.modules.usuario.application.dto.LoginRequestDto;
import br.senai.carteirinha.modules.usuario.application.service.AutenticarUsuarioService;
import br.senai.carteirinha.modules.usuario.domain.CredenciaisInvalidasException;
import br.senai.carteirinha.modules.usuario.domain.PerfilAcesso;
import br.senai.carteirinha.modules.usuario.domain.Usuario;
import org.junit.jupiter.api.Test;

import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class AutenticarUsuarioServiceTest {

    private static final UUID ID =
        UUID.fromString(
            "00000000-0000-0000-0000-000000000001"
        );

    @Test
    void deveAutenticarAlunoEDevolverPerfil() {

        Usuario usuario =
            usuarioAtivo();

        var service =
            new AutenticarUsuarioService(
                login ->
                    Optional.of(
                        usuario
                    ),
                (senhaPura, hash) ->
                    senhaPura.equals("123")
                        && hash.equals(
                            "hash-da-senha"
                        ),
                user ->
                    "token-gerado-pelo-adaptador"
            );

        var resultado =
            service.autenticar(
                new LoginRequestDto(
                    " aluno ",
                    "123"
                )
            );

        assertEquals(
            ID.toString(),
            resultado.id()
        );

        assertEquals(
            "Erik Takeyama",
            resultado.nome()
        );

        assertEquals(
            "01579342",
            resultado.matricula()
        );

        assertEquals(
            "ALUNO",
            resultado.perfil()
        );

        assertEquals(
            "Desenvolvimento de Sistemas",
            resultado.curso()
        );

        assertEquals(
            "2DEVEST-A",
            resultado.turma()
        );

        assertEquals(
            "token-gerado-pelo-adaptador",
            resultado.token()
        );
    }

    @Test
    void deveAutenticarProfessorSemCursoOuTurma() {

        Usuario professor =
            new Usuario(
                UUID.fromString(
                    "00000000-0000-0000-0000-000000000003"
                ),
                "professor",
                "hash-da-senha",
                "Professor Modelo",
                "PROF20260001",
                PerfilAcesso.PROFESSOR,
                "",
                "",
                true
            );

        var service =
            new AutenticarUsuarioService(
                login ->
                    Optional.of(
                        professor
                    ),
                (senha, hash) ->
                    true,
                usuario ->
                    "token-professor"
            );

        var resultado =
            service.autenticar(
                new LoginRequestDto(
                    "professor",
                    "123"
                )
            );

        assertEquals(
            "PROFESSOR",
            resultado.perfil()
        );

        assertEquals(
            "",
            resultado.curso()
        );

        assertEquals(
            "",
            resultado.turma()
        );
    }

    @Test
    void deveRecusarQuandoUsuarioNaoExiste() {

        var service =
            new AutenticarUsuarioService(
                login ->
                    Optional.empty(),
                (senha, hash) ->
                    true,
                usuario ->
                    "token"
            );

        assertThrows(
            CredenciaisInvalidasException.class,
            () ->
                service.autenticar(
                    new LoginRequestDto(
                        "desconhecido",
                        "123"
                    )
                )
        );
    }

    @Test
    void deveRecusarSenhaIncorreta() {

        var service =
            new AutenticarUsuarioService(
                login ->
                    Optional.of(
                        usuarioAtivo()
                    ),
                (senha, hash) ->
                    false,
                usuario ->
                    "token"
            );

        assertThrows(
            CredenciaisInvalidasException.class,
            () ->
                service.autenticar(
                    new LoginRequestDto(
                        "aluno",
                        "senha-errada"
                    )
                )
        );
    }

    @Test
    void deveRecusarUsuarioInativo() {

        Usuario inativo =
            new Usuario(
                ID,
                "aluno",
                "hash-da-senha",
                "Erik Takeyama",
                "01579342",
                PerfilAcesso.ALUNO,
                "Desenvolvimento de Sistemas",
                "2DEVEST-A",
                false
            );

        var service =
            new AutenticarUsuarioService(
                login ->
                    Optional.of(
                        inativo
                    ),
                (senha, hash) ->
                    true,
                usuario ->
                    "token"
            );

        assertThrows(
            CredenciaisInvalidasException.class,
            () ->
                service.autenticar(
                    new LoginRequestDto(
                        "aluno",
                        "123"
                    )
                )
        );
    }

    private Usuario usuarioAtivo() {

        return new Usuario(
            ID,
            "aluno",
            "hash-da-senha",
            "Erik Takeyama",
            "01579342",
            PerfilAcesso.ALUNO,
            "Desenvolvimento de Sistemas",
            "2DEVEST-A",
            true
        );
    }
}